<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Task Controller</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="m-4">
    <button type="submit" class="btn btn-success"><a href="<?php echo e(url('salesPerson')); ?>">Back</a></button>
    <form action="<?php echo e(route('assignTask')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <input type="hidden" class="form-control" id="inputEmail" name="phone_no" value="<?php echo e($worker->phone_no); ?>" >
        </div>
        <div class="mb-3">
            <input type="hidden" class="form-control" id="inputEmail" name="worker_id" value="<?php echo e($worker->id); ?>" >
        </div>
        <div class="mb-3">
            <label class="form-label" for="inputPassword">Task</label>
            <input type="text" class="form-control" id="inputPassword" name="task" placeholder="assign task" >
        </div>

        <button type="submit" class="btn btn-primary">Assign</button>
    </form>
</div>
</body>
</html><?php /**PATH /home/jaylinkz/jayBawaSystems/resources/views/admin/managers/task.blade.php ENDPATH**/ ?>