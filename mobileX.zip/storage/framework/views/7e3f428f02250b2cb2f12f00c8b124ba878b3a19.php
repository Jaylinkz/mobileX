<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Transfer</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>
  <div class="container">
<div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2> Transfer</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(Url('manageProducts')); ?>"> Back</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Name:</strong>
                <?php echo e($product->name); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Quantity:</strong>
                <?php echo e($product->quantity); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <form method="post" action="<?php echo e(route('transfer')); ?>">
                    <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                </div>
                <div class="form-group">
                    <input type="number" name="quantity" placeholder="quantity">
                </div>
                <div class="form-group">
                        <select  id="categories" name="store"  multiple required>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value ="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <div class="form-group">
                            <button>Transfer</button>
                          </div>
				</div> 

                </form>
            </div>
        </div>

    </div>
    </div>
</body>
</html><?php /**PATH /home/jaylinkz/jayBawaSystems/resources/views/admin/products/show.blade.php ENDPATH**/ ?>